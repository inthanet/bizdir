-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 02, 2022 at 12:10 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bizbook_plus_directory`
--

-- --------------------------------------------------------

--
-- Table structure for table `vv_custom_css`
--

CREATE TABLE `vv_custom_css` (
  `custom_css_id` int(11) NOT NULL,
  `home_search_btn_default` varchar(20) DEFAULT NULL,
  `home_search_btn_hover` varchar(20) DEFAULT NULL,
  `home_banner_btn_default` varchar(20) DEFAULT NULL,
  `home_banner_btn_hover` varchar(20) DEFAULT NULL,
  `home_view_all_btn_default` varchar(20) DEFAULT NULL,
  `home_view_all_btn_hover` varchar(20) DEFAULT NULL,
  `common_help_support_btn_default` varchar(20) DEFAULT NULL,
  `common_help_support_btn_hover` varchar(20) DEFAULT NULL,
  `home_submit_req_btn_default` varchar(20) DEFAULT '1',
  `home_submit_req_btn_hover` varchar(20) DEFAULT NULL,
  `common_blue_btn` varchar(20) DEFAULT NULL,
  `common_light_blue_btn` varchar(20) DEFAULT NULL,
  `common_red_btn` varchar(20) DEFAULT NULL,
  `common_dark_red_btn` varchar(20) DEFAULT '0',
  `common_yellow_bottom_band` varchar(20) DEFAULT NULL,
  `common_yellow_1_bottom_band` varchar(20) DEFAULT NULL,
  `common_yellow_2_btn` varchar(20) DEFAULT NULL,
  `common_gray_color` varchar(20) DEFAULT NULL,
  `common_green_color` varchar(20) DEFAULT NULL,
  `common_light_green_color` varchar(20) DEFAULT NULL,
  `job_blue_color` varchar(20) DEFAULT NULL,
  `job_orange_color` varchar(20) DEFAULT NULL,
  `custom_css_cdt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vv_custom_css`
--

INSERT INTO `vv_custom_css` (`custom_css_id`, `home_search_btn_default`, `home_search_btn_hover`, `home_banner_btn_default`, `home_banner_btn_hover`, `home_view_all_btn_default`, `home_view_all_btn_hover`, `common_help_support_btn_default`, `common_help_support_btn_hover`, `home_submit_req_btn_default`, `home_submit_req_btn_hover`, `common_blue_btn`, `common_light_blue_btn`, `common_red_btn`, `common_dark_red_btn`, `common_yellow_bottom_band`, `common_yellow_1_bottom_band`, `common_yellow_2_btn`, `common_gray_color`, `common_green_color`, `common_light_green_color`, `job_blue_color`, `job_orange_color`, `custom_css_cdt`) VALUES
(1, '#0070d2', '#0664b7', '#3f4550', '#0070d2', '#075376', '#0070d2', '#21d78d', '#149f5c', '#21d78d', '#149f5c', '#0070d2', '#03A9F4', '#f44336', '#da2013', '#ffea31', '#ffbe5e', '#FFC107', '#0a2236', '#149f5c', '#7dc34a', '#0337f4', '#ff9800', '2021-09-26 10:00:00'),
(2, '#0070d2', '#0664b7', '#3f4550', '#0070d2', '#075376', '#0070d2', '#21d78d', '#149f5c', '#21d78d', '#149f5c', '#0070d2', '#03A9F4', '#f44336', '#da2013', '#ffea31', '#ffbe5e', '#FFC107', '#0a2236', '#149f5c', '#7dc34a', '#0337f4', '#ff9800', '2021-09-26 10:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `vv_experts`
--

CREATE TABLE `vv_experts` (
  `expert_id` int(11) NOT NULL,
  `expert_code` varchar(20) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_plan` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `sub_category_id` text,
  `city_id` int(11) DEFAULT NULL,
  `area_id` text,
  `profile_name` varchar(50) DEFAULT NULL,
  `base_fare` varchar(20) DEFAULT NULL,
  `years_of_experience` int(11) DEFAULT NULL,
  `available_time_start` varchar(20) DEFAULT NULL,
  `available_time_end` varchar(20) DEFAULT NULL,
  `profile_image` text,
  `cover_image` text,
  `date_of_birth` date DEFAULT NULL,
  `id_proof` text,
  `payment_id` text,
  `experience_1` text,
  `experience_2` text,
  `experience_3` text,
  `experience_4` text,
  `education_1` text,
  `education_2` text,
  `education_3` text,
  `education_4` text,
  `additional_info_1` text,
  `additional_info_2` text,
  `additional_info_3` text,
  `additional_info_4` text,
  `expert_availability_status` int(11) NOT NULL,
  `expert_status` varchar(20) DEFAULT NULL,
  `seo_title` text NOT NULL,
  `seo_description` text NOT NULL,
  `seo_keywords` text NOT NULL,
  `expert_slug` varchar(50) DEFAULT NULL,
  `expert_udt` datetime DEFAULT NULL,
  `expert_cdt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vv_experts`
--

INSERT INTO `vv_experts` (`expert_id`, `expert_code`, `user_id`, `user_plan`, `category_id`, `sub_category_id`, `city_id`, `area_id`, `profile_name`, `base_fare`, `years_of_experience`, `available_time_start`, `available_time_end`, `profile_image`, `cover_image`, `date_of_birth`, `id_proof`, `payment_id`, `experience_1`, `experience_2`, `experience_3`, `experience_4`, `education_1`, `education_2`, `education_3`, `education_4`, `additional_info_1`, `additional_info_2`, `additional_info_3`, `additional_info_4`, `expert_availability_status`, `expert_status`, `seo_title`, `seo_description`, `seo_keywords`, `expert_slug`, `expert_udt`, `expert_cdt`) VALUES
(3, 'EXPERT-SERVICE003', 35, 4, 22, '45,42,38', 1, '1', 'Directory Finder', '50', 6, '6:00 AM', '10:00 PM', '79477bean.jpg', '84115bean1.jpg', '1993-07-16', '30306bean.jpg', '2,1', 'exp 1', 'exp 2', 'exp 3', 'exp 4', 'edu 1', 'edu 2', 'edu 3', 'edu 4', 'addi 1', 'addi 2', 'addi 3', 'addi 4', 1, 'Active', '', '', '', 'directory finder', '2021-09-06 12:12:29', '2021-08-19 15:42:25'),
(4, 'EXPERT-SERVICE004', 37, 4, 22, '44,30,29', 1, '2', 'Rn53 Themes', '5000', 5, '6:00 AM', '10:00 AM', '96118bean.jpg', '16885bean1.jpg', '1993-07-09', '6486bean.jpg', '2', 'exp 1', 'exp 2', 'exp 3', 'exp 4', 'edu 1', 'edu 2', 'edu 3', 'edu 4', 'addi 1', 'addi 2', 'addi 3', 'addi 4', 0, 'Active', 'test viki title', 'test viki description', 'test viki keywords', 'rn53 themes', '2021-09-06 12:48:58', '2021-09-06 12:48:58');

-- --------------------------------------------------------

--
-- Table structure for table `vv_expert_areas`
--

CREATE TABLE `vv_expert_areas` (
  `city_id` int(11) NOT NULL,
  `city_name` varchar(30) NOT NULL,
  `state_id` int(11) NOT NULL,
  `city_cdt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vv_expert_areas`
--

INSERT INTO `vv_expert_areas` (`city_id`, `city_name`, `state_id`, `city_cdt`) VALUES
(1, 'Old Washermenpet', 1, '2021-08-16 13:09:18'),
(2, 'Royapuram', 1, '2021-08-16 13:09:18'),
(3, 'RS Puram', 2, '2021-08-16 13:19:55');

-- --------------------------------------------------------

--
-- Table structure for table `vv_expert_categories`
--

CREATE TABLE `vv_expert_categories` (
  `category_id` int(11) NOT NULL,
  `category_code` varchar(20) DEFAULT NULL,
  `category_name` text,
  `category_image` text,
  `category_filter` int(11) DEFAULT '0',
  `category_filter_pos_id` int(11) DEFAULT NULL,
  `category_status` varchar(20) DEFAULT NULL,
  `category_slug` text,
  `category_cdt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vv_expert_categories`
--

INSERT INTO `vv_expert_categories` (`category_id`, `category_code`, `category_name`, `category_image`, `category_filter`, `category_filter_pos_id`, `category_status`, `category_slug`, `category_cdt`) VALUES
(5, 'CAT005', 'Automobilers', '48466ser4.jpg', 0, 6, 'Active', 'Automobilers', '2017-09-29 10:21:20'),
(6, 'CAT006', 'Electricals', '48466ser4.jpg', 0, 11, 'Active', 'Electricals', '2017-09-29 09:21:16'),
(7, 'CAT007', 'Education', '48466ser4.jpg', 0, 10, 'Active', 'Education', '2017-09-29 06:14:18'),
(8, 'CAT008', 'Sports', '48466ser4.jpg', 0, 9, 'Active', 'Sports', '2017-09-29 07:17:17'),
(15, 'CAT015', 'Clothings', '48466ser4.jpg', 0, 1, 'Active', 'Clothings', '2020-04-10 01:36:33'),
(16, 'CAT016', 'Footwear', '48466ser4.jpg', 0, 0, 'Active', 'Footwear', '2020-04-10 01:36:33'),
(17, 'CAT017', 'Shoes', '48466ser4.jpg', 0, 2, 'Active', 'Shoes', '2020-04-10 01:36:33'),
(18, 'CAT018', 'Jewellery', '48466ser4.jpg', 0, 3, 'Active', 'Jewellery', '2020-04-10 01:36:33'),
(19, 'CAT019', 'Toys', '48466ser4.jpg', 0, 4, 'Active', 'Toys', '2020-04-10 01:36:33'),
(20, 'CAT020', 'Baby care', '48466ser4.jpg', 0, 5, 'Active', 'Baby care', '2020-04-10 01:36:33'),
(21, 'CAT021', 'Fruits', '48466ser4.jpg', 0, 7, 'Active', 'Fruits', '2020-04-10 15:13:12'),
(22, 'CAT022', 'Mens', '48466ser4.jpg', 0, 8, 'Active', 'Mens', '2020-04-11 15:27:16');

-- --------------------------------------------------------

--
-- Table structure for table `vv_expert_cities`
--

CREATE TABLE `vv_expert_cities` (
  `country_id` int(11) NOT NULL,
  `country_name` varchar(150) NOT NULL,
  `country_cdt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vv_expert_cities`
--

INSERT INTO `vv_expert_cities` (`country_id`, `country_name`, `country_cdt`) VALUES
(1, 'Chennai', '2021-08-16 12:44:46'),
(2, 'Madurai', '2021-08-16 12:44:46'),
(3, 'Coimbatore', '2021-08-16 12:52:48');

-- --------------------------------------------------------

--
-- Table structure for table `vv_expert_enquiries`
--

CREATE TABLE `vv_expert_enquiries` (
  `enquiry_id` int(11) NOT NULL,
  `expert_id` int(11) DEFAULT NULL,
  `expert_user_id` int(11) DEFAULT NULL,
  `enquiry_sender_id` int(11) DEFAULT NULL,
  `enquiry_source` varchar(20) DEFAULT NULL,
  `enquiry_name` varchar(100) DEFAULT NULL,
  `enquiry_email` varchar(100) DEFAULT NULL,
  `enquiry_mobile` varchar(20) DEFAULT NULL,
  `appointment_date` date DEFAULT NULL,
  `appointment_time` varchar(20) DEFAULT NULL,
  `enquiry_message` text,
  `enquiry_category` int(11) DEFAULT NULL,
  `enquiry_location` text,
  `payment_id` varchar(50) DEFAULT NULL,
  `is_general_id` int(11) DEFAULT '0',
  `total_amount` varchar(50) DEFAULT NULL,
  `admin_amount` varchar(50) DEFAULT NULL,
  `user_amount` varchar(50) DEFAULT NULL,
  `payment_status` varchar(50) DEFAULT NULL,
  `enquiry_save` int(11) DEFAULT NULL,
  `enquiry_status` int(11) DEFAULT NULL,
  `cancel_reason` text,
  `enquiry_cdt` datetime DEFAULT NULL,
  `enquiry_udt` datetime DEFAULT NULL,
  `payment_cdt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vv_expert_enquiries`
--

INSERT INTO `vv_expert_enquiries` (`enquiry_id`, `expert_id`, `expert_user_id`, `enquiry_sender_id`, `enquiry_source`, `enquiry_name`, `enquiry_email`, `enquiry_mobile`, `appointment_date`, `appointment_time`, `enquiry_message`, `enquiry_category`, `enquiry_location`, `payment_id`, `is_general_id`, `total_amount`, `admin_amount`, `user_amount`, `payment_status`, `enquiry_save`, `enquiry_status`, `cancel_reason`, `enquiry_cdt`, `enquiry_udt`, `payment_cdt`) VALUES
(3, 3, 35, 51, 'Website', 'test2 viki', 'free@gmail.com', '7894561230', '2021-08-20', '10:00 AM', 'test2 viki2', 20, '', '', 0, '', '', '', 'Pending', 0, 500, '', '2021-08-26 11:50:09', '2021-08-28 13:09:50', '0000-00-00 00:00:00'),
(4, 3, 35, 51, 'Website', 'test viki 3', 'free@gmail.com', '8745961230', '2021-08-26', '7:00 AM', 'test viki 3', 22, '', '', 0, '', '', '', 'Pending', 0, 300, '', '2021-08-26 11:54:12', '2021-08-28 12:59:27', '0000-00-00 00:00:00'),
(6, 4, 37, 35, 'Website', 'test viki', 'vicky@gmail.com', '7845963210', '0000-00-00', '7:00 AM', 'asas', 22, 'asas', NULL, 0, NULL, NULL, NULL, 'Pending', NULL, 200, NULL, '2021-09-09 11:00:31', NULL, NULL),
(7, 4, 37, 51, 'Website', 'hi', 'free@gmail.com', '00000000', '2021-11-21', '9:00 AM', '', 15, 'tedjh', NULL, 0, NULL, NULL, NULL, 'Pending', NULL, 200, NULL, '2021-10-26 11:46:30', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vv_expert_payments`
--

CREATE TABLE `vv_expert_payments` (
  `payment_id` int(11) NOT NULL,
  `payment_name` varchar(100) NOT NULL,
  `payment_status` varchar(20) NOT NULL,
  `payment_cdt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vv_expert_payments`
--

INSERT INTO `vv_expert_payments` (`payment_id`, `payment_name`, `payment_status`, `payment_cdt`) VALUES
(1, 'Google Pay', 'Active', '2021-08-16 11:54:00'),
(2, 'Stripe', 'Active', '2021-08-16 11:54:00');

-- --------------------------------------------------------

--
-- Table structure for table `vv_expert_reviews`
--

CREATE TABLE `vv_expert_reviews` (
  `review_id` int(11) NOT NULL,
  `expert_id` int(11) NOT NULL,
  `expert_user_id` int(11) NOT NULL,
  `review_user_id` int(11) NOT NULL,
  `enquiry_id` int(11) NOT NULL,
  `expert_rating` int(11) NOT NULL,
  `expert_message` text NOT NULL,
  `review_status` varchar(20) NOT NULL,
  `review_save` int(11) NOT NULL,
  `review_cdt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vv_expert_reviews`
--

INSERT INTO `vv_expert_reviews` (`review_id`, `expert_id`, `expert_user_id`, `review_user_id`, `enquiry_id`, `expert_rating`, `expert_message`, `review_status`, `review_save`, `review_cdt`) VALUES
(4, 3, 35, 51, 3, 4, 'Great job!!', 'Active', 0, '2021-09-18 11:26:39');

-- --------------------------------------------------------

--
-- Table structure for table `vv_expert_sub_categories`
--

CREATE TABLE `vv_expert_sub_categories` (
  `sub_category_id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `sub_category_code` varchar(20) DEFAULT NULL,
  `sub_category_name` text,
  `sub_category_image` text,
  `sub_category_status` varchar(20) DEFAULT NULL,
  `sub_category_slug` text,
  `sub_category_cdt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vv_expert_sub_categories`
--

INSERT INTO `vv_expert_sub_categories` (`sub_category_id`, `category_id`, `sub_category_code`, `sub_category_name`, `sub_category_image`, `sub_category_status`, `sub_category_slug`, `sub_category_cdt`) VALUES
(8, 6, 'SUB_CAT008', 'Mobiles', '', 'Active', '', '2020-04-08 10:19:36'),
(9, 6, 'SUB_CAT009', 'Smart TV', '', 'Active', '', '2020-04-08 10:19:36'),
(10, 6, 'SUB_CAT010', 'Laptop', '', 'Active', '', '2020-04-08 10:19:36'),
(11, 6, 'SUB_CAT011', 'Speakers', '', 'Active', '', '2020-04-08 10:19:36'),
(12, 6, 'SUB_CAT012', 'Camera', '', 'Active', '', '2020-04-08 10:19:36'),
(13, 6, 'SUB_CAT013', 'Tablets', '', 'Active', '', '2020-04-08 10:19:36'),
(14, 6, 'SUB_CAT014', 'Smart Tech', '', 'Active', '', '2020-04-08 10:19:36'),
(15, 17, 'SUB_CAT015', 'Adidas', '', 'Active', '', '2020-04-10 01:37:25'),
(16, 17, 'SUB_CAT016', 'Nike', '', 'Active', '', '2020-04-10 01:37:25'),
(17, 17, 'SUB_CAT017', 'Puma', '', 'Active', '', '2020-04-10 01:37:25'),
(18, 19, 'SUB_CAT018', 'Educations toys', '', 'Active', '', '2020-04-10 01:38:17'),
(19, 19, 'SUB_CAT019', 'Brain games', '', 'Active', '', '2020-04-10 01:38:17'),
(20, 19, 'SUB_CAT020', 'Drone toys', '', 'Active', '', '2020-04-10 01:38:17'),
(21, 19, 'SUB_CAT021', 'Playstations games', '', 'Active', '', '2020-04-10 01:38:17'),
(22, 19, 'SUB_CAT022', 'PC games', '', 'Active', '', '2020-04-10 01:38:17'),
(23, 15, 'SUB_CAT023', 'T-shirts', '', 'Active', '', '2020-04-10 01:38:49'),
(24, 15, 'SUB_CAT024', 'Shirts', '', 'Active', '', '2020-04-10 01:38:49'),
(25, 15, 'SUB_CAT025', 'Jeans', '', 'Active', '', '2020-04-10 01:38:49'),
(26, 7, 'SUB_CAT026', 'Books', '', 'Active', '', '2020-04-10 15:04:44'),
(27, 7, 'SUB_CAT027', 'Digital books', '', 'Active', '', '2020-04-10 15:04:44'),
(28, 7, 'SUB_CAT028', 'Digital products', '', 'Active', '', '2020-04-10 15:04:44'),
(29, 21, 'SUB_CAT029', 'Fruits', '', 'Active', '', '2020-04-10 15:13:51'),
(30, 21, 'SUB_CAT030', 'Vegitables', '', 'Active', '', '2020-04-10 15:13:51'),
(31, 21, 'SUB_CAT031', 'Fruits and vegitables', '', 'Active', '', '2020-04-10 15:13:51'),
(32, 6, 'SUB_CAT032', 'Camera holder', '', 'Active', '', '2020-04-11 15:19:18'),
(33, 6, 'SUB_CAT033', 'Camera pouch', '', 'Active', '', '2020-04-11 15:19:18'),
(34, 6, 'SUB_CAT034', 'Camera light', '', 'Active', '', '2020-04-11 15:19:18'),
(35, 6, 'SUB_CAT035', 'Camera lense', '', 'Active', '', '2020-04-11 15:19:18'),
(37, 22, 'SUB_CAT037', 'Tshirts', '', 'Active', '', '2020-04-11 15:28:13'),
(38, 22, 'SUB_CAT038', 'Food', '', 'Active', 'Food', '2020-04-27 21:57:58'),
(42, 22, 'SUB_CAT042', 'wer', NULL, 'Active', 'wer', '2021-08-13 18:23:07'),
(43, 22, 'SUB_CAT043', 'erw', NULL, 'Active', 'erw', '2021-08-13 18:23:07'),
(44, 21, 'SUB_CAT044', 'apple', NULL, 'Active', 'apple', '2021-08-13 18:28:45'),
(45, 22, 'SUB_CAT045', 'orange1', NULL, 'Active', 'orange1', '2021-08-13 18:28:45');

-- --------------------------------------------------------

--
-- Table structure for table `vv_jobs`
--

CREATE TABLE `vv_jobs` (
  `job_id` int(11) NOT NULL,
  `job_code` varchar(20) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `category_id` varchar(50) DEFAULT NULL,
  `sub_category_id` varchar(50) DEFAULT NULL,
  `job_title` varchar(100) DEFAULT NULL,
  `job_salary` int(11) DEFAULT NULL,
  `no_of_openings` int(11) DEFAULT NULL,
  `job_type` int(11) DEFAULT NULL,
  `job_interview_date` date DEFAULT NULL,
  `years_of_experience` int(11) DEFAULT NULL,
  `job_interview_time` time DEFAULT NULL,
  `job_role` varchar(100) DEFAULT NULL,
  `educational_qualification` text,
  `job_description` text,
  `job_small_description` text,
  `job_location` int(11) DEFAULT NULL,
  `job_company_name` varchar(100) NOT NULL,
  `company_logo` text,
  `contact_person` varchar(100) DEFAULT NULL,
  `contact_email_id` varchar(100) DEFAULT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `contact_website` varchar(100) DEFAULT NULL,
  `interview_location` text,
  `skill_set` varchar(100) DEFAULT NULL,
  `job_status` varchar(20) DEFAULT NULL,
  `seo_title` text NOT NULL,
  `seo_description` text NOT NULL,
  `seo_keywords` text NOT NULL,
  `job_slug` text,
  `job_udt` datetime DEFAULT NULL,
  `job_cdt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vv_jobs`
--

INSERT INTO `vv_jobs` (`job_id`, `job_code`, `user_id`, `category_id`, `sub_category_id`, `job_title`, `job_salary`, `no_of_openings`, `job_type`, `job_interview_date`, `years_of_experience`, `job_interview_time`, `job_role`, `educational_qualification`, `job_description`, `job_small_description`, `job_location`, `job_company_name`, `company_logo`, `contact_person`, `contact_email_id`, `contact_number`, `contact_website`, `interview_location`, `skill_set`, `job_status`, `seo_title`, `seo_description`, `seo_keywords`, `job_slug`, `job_udt`, `job_cdt`) VALUES
(1, 'JOB001', 35, '22', '', 'Test Job', 0, 5, 1, '2021-06-26', 6, '16:00:00', 'Software Engineer', 'B.E Any Stream', '<p>What is Lorem Ipsum? Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing</p>\r\n', 'dsda dsa ', 1, 'Cognizant', '41194bean1.jpg', 'Vignesh', 'vikivignesh367@gmail.com', '07401162301', '', '', '18,6,5', 'Active', 'test viki title', 'test viki description', 'test viki keywords', 'Test Job', '2021-06-26 12:59:17', '2021-06-18 12:36:25'),
(2, 'JOB002', 35, '19', '', 'Test Job1', 0, 5, 2, '2021-06-26', 6, '10:30:00', 'Software Engineer', 'B.E Any Stream', '<p>What is Lorem Ipsum? Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing</p>\r\n', 'd asdadas', 2, 'Cognizant', '51289bean.jpg', 'Vignesh', 'vikivignesh367@gmail.com', '07401162301', 'https://google.com', 'Chennai', '18', 'Active', '', '', '', 'Test Job1', '2021-06-26 12:58:55', '2021-06-18 12:38:47'),
(3, 'JOB003', 35, '17', '16', 'Test Job2', 500, 7, 4, '2021-07-02', 3, '11:30:00', 'Software Engineer', 'B.E Any Stream', '<p>What is Lorem Ipsum? Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing</p>\r\n', 'hjfgasdad  hjjgjhg', 5, 'Zoho', '74450bean.jpg', 'Vignesh', 'vikivignesh367@gmail.com', '07401162301', 'https://google.com', 'Chennai', '21', 'Active', '', '', '', 'Test Job2', '2021-06-26 12:58:11', '2021-06-18 12:42:58');

-- --------------------------------------------------------

--
-- Table structure for table `vv_job_applied`
--

CREATE TABLE `vv_job_applied` (
  `job_applied_id` int(11) NOT NULL,
  `job_id` int(11) NOT NULL,
  `job_user_id` int(11) NOT NULL,
  `job_profile_id` int(11) NOT NULL,
  `job_applied_status` varchar(10) NOT NULL,
  `job_applied_cdt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vv_job_applied`
--

INSERT INTO `vv_job_applied` (`job_applied_id`, `job_id`, `job_user_id`, `job_profile_id`, `job_applied_status`, `job_applied_cdt`) VALUES
(6, 1, 35, 322, 'Active', '2021-07-11 18:28:32');

-- --------------------------------------------------------

--
-- Table structure for table `vv_job_categories`
--

CREATE TABLE `vv_job_categories` (
  `category_id` int(11) NOT NULL,
  `category_code` varchar(20) DEFAULT NULL,
  `category_name` text,
  `category_image` text,
  `category_filter` int(11) DEFAULT '0',
  `category_filter_pos_id` int(11) DEFAULT NULL,
  `category_status` varchar(20) DEFAULT NULL,
  `category_slug` text,
  `category_cdt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vv_job_categories`
--

INSERT INTO `vv_job_categories` (`category_id`, `category_code`, `category_name`, `category_image`, `category_filter`, `category_filter_pos_id`, `category_status`, `category_slug`, `category_cdt`) VALUES
(5, 'CAT005', 'Automobilers', '', 0, 8, 'Active', 'Automobilers', '2017-09-29 10:21:20'),
(6, 'CAT006', 'Electricals', '', 0, 7, 'Active', 'Electricals', '2017-09-29 09:21:16'),
(7, 'CAT007', 'Education', '', 0, 5, 'Active', 'Education', '2017-09-29 06:14:18'),
(8, 'CAT008', 'Sports', '', 0, 4, 'Active', 'Sports', '2017-09-29 07:17:17'),
(15, 'CAT015', 'Clothings', '', 0, 1, 'Active', 'Clothings', '2020-04-10 01:36:33'),
(16, 'CAT016', 'Footwear', '', 0, 1, 'Active', 'Footwear', '2020-04-10 01:36:33'),
(17, 'CAT017', 'Shoes', '4151018945man-with-fireworks-769525.jpg', 0, 1, 'Active', 'Shoes', '2020-04-10 01:36:33'),
(18, 'CAT018', 'Jewellery', '', 0, 1, 'Active', 'Jewellery', '2020-04-10 01:36:33'),
(19, 'CAT019', 'Toys', '', 0, 1, 'Active', 'Toys', '2020-04-10 01:36:33'),
(20, 'CAT020', 'Baby care', '', 0, 1, 'Active', 'Baby care', '2020-04-10 01:36:33'),
(21, 'CAT021', 'Fruits', '', 0, 1, 'Active', 'Fruits', '2020-04-10 15:13:12'),
(22, 'CAT022', 'Mens', '', 0, 1, 'Active', 'Mens', '2020-04-11 15:27:16'),
(23, 'CAT023', 'Health', '', 0, 1, 'Active', 'Health', '2020-04-27 21:56:45');

-- --------------------------------------------------------

--
-- Table structure for table `vv_job_cities`
--

CREATE TABLE `vv_job_cities` (
  `city_id` int(11) NOT NULL,
  `city_name` varchar(100) NOT NULL,
  `city_cdt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vv_job_cities`
--

INSERT INTO `vv_job_cities` (`city_id`, `city_name`, `city_cdt`) VALUES
(1, 'Chennai', '2021-06-25 15:15:07'),
(2, 'Kolkata', '2021-06-25 15:15:07'),
(4, 'Bengaluru', '2021-06-26 13:13:48'),
(5, 'Mumbai', '2021-06-26 13:13:48'),
(6, 'Cochin', '2021-06-26 13:13:48');

-- --------------------------------------------------------

--
-- Table structure for table `vv_job_popular`
--

CREATE TABLE `vv_job_popular` (
  `job_popular_id` int(11) NOT NULL,
  `job_name` text NOT NULL,
  `job_popular_pos_id` int(11) NOT NULL,
  `job_popular_status` varchar(20) NOT NULL,
  `job_popular_cdt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vv_job_popular`
--

INSERT INTO `vv_job_popular` (`job_popular_id`, `job_name`, `job_popular_pos_id`, `job_popular_status`, `job_popular_cdt`) VALUES
(1, '3', 1, 'Active', '2021-07-19 13:19:46'),
(2, '1', 2, 'Active', '2021-07-19 13:19:46'),
(3, '2', 3, 'Active', '2021-07-19 13:19:46'),
(4, '1', 4, 'Active', '2021-07-19 13:19:46'),
(5, '1', 5, 'Active', '2021-07-19 13:19:46'),
(6, '1', 6, 'Active', '2021-07-19 13:19:46'),
(7, '1', 7, 'Active', '2021-07-19 13:19:46'),
(8, '1', 8, 'Active', '2021-07-19 13:19:46'),
(9, '1', 9, 'Active', '2021-07-19 13:19:46'),
(10, '1', 10, 'Active', '2021-07-19 13:19:46');

-- --------------------------------------------------------

--
-- Table structure for table `vv_job_profile`
--

CREATE TABLE `vv_job_profile` (
  `job_profile_id` int(11) NOT NULL,
  `job_profile_code` varchar(20) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `sub_category_id` int(11) DEFAULT NULL,
  `profile_name` varchar(50) DEFAULT NULL,
  `current_company` text,
  `years_of_experience` int(11) DEFAULT NULL,
  `notice_period` int(11) DEFAULT NULL,
  `available_time_start` varchar(20) DEFAULT NULL,
  `available_time_end` varchar(20) DEFAULT NULL,
  `educational_qualification` text,
  `job_profile_image` text,
  `cover_image` text,
  `job_profile_resume` text,
  `skill_set` varchar(100) DEFAULT NULL,
  `experience_1` text,
  `experience_2` text,
  `experience_3` text,
  `experience_4` text,
  `education_1` text,
  `education_2` text,
  `education_3` text,
  `education_4` text,
  `additional_info_1` text,
  `additional_info_2` text,
  `additional_info_3` text,
  `additional_info_4` text,
  `job_profile_status` varchar(20) DEFAULT NULL,
  `job_profile_slug` varchar(50) DEFAULT NULL,
  `job_profile_udt` datetime DEFAULT NULL,
  `job_profile_cdt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vv_job_profile`
--

INSERT INTO `vv_job_profile` (`job_profile_id`, `job_profile_code`, `user_id`, `category_id`, `sub_category_id`, `profile_name`, `current_company`, `years_of_experience`, `notice_period`, `available_time_start`, `available_time_end`, `educational_qualification`, `job_profile_image`, `cover_image`, `job_profile_resume`, `skill_set`, `experience_1`, `experience_2`, `experience_3`, `experience_4`, `education_1`, `education_2`, `education_3`, `education_4`, `additional_info_1`, `additional_info_2`, `additional_info_3`, `additional_info_4`, `job_profile_status`, `job_profile_slug`, `job_profile_udt`, `job_profile_cdt`) VALUES
(1, 'JOB-PROFILE001', 37, 15, 25, 'Directory Finder', 'Insoft Pvt. Ltd', 6, 5, '12:30', NULL, 'B.E CSE', NULL, '15598bean.jpg', '28702viki_resume_final.docx', '19,18,16,6', 'exp 1', 'exp 2', 'exp 3', 'exp 4', 'edu 1', 'edu 2', 'edu 3', 'edu 4', 'addi 1', 'addi 2', 'addi 3', 'addi 4', 'Active', 'directory finder', '2021-06-20 14:09:51', '2021-06-20 14:04:46'),
(3, 'JOB-PROFILE003', 322, 23, 39, 'Job Seeker Viki', 'Insoft Pvt. Ltd', 3, 2, '10:30', NULL, 'B.E CSE', '8589bean4.jpg', '57246bean1.jpg', '4861bean.jpg', '21,19,17,16', 'exp 1', 'exp 2', 'exp 3', 'exp 4', 'edu 1', 'edu 2', 'edu 3', 'edu 4', 'addi 1', 'addi 2', 'addi 3', 'addi 4', 'Active', 'Job Seeker Viki', '2021-11-08 12:29:37', '2021-07-11 18:28:08');

-- --------------------------------------------------------

--
-- Table structure for table `vv_job_skill`
--

CREATE TABLE `vv_job_skill` (
  `category_id` int(11) NOT NULL,
  `category_code` varchar(20) DEFAULT NULL,
  `category_name` text,
  `category_image` text,
  `category_filter` int(11) DEFAULT '0',
  `category_filter_pos_id` int(11) DEFAULT NULL,
  `category_status` varchar(20) DEFAULT NULL,
  `category_slug` text,
  `category_cdt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vv_job_skill`
--

INSERT INTO `vv_job_skill` (`category_id`, `category_code`, `category_name`, `category_image`, `category_filter`, `category_filter_pos_id`, `category_status`, `category_slug`, `category_cdt`) VALUES
(5, 'CAT005', 'Automobilers', '4.jpg', 0, 8, 'Active', '', '2017-09-29 10:21:20'),
(6, 'CAT006', 'Electricals', '5.jpg', 0, 7, 'Active', '', '2017-09-29 09:21:16'),
(7, 'CAT007', 'Education', '6.jpg', 0, 5, 'Active', '', '2017-09-29 06:14:18'),
(8, 'CAT008', 'Sports', '2.jpg', 0, 4, 'Active', '', '2017-09-29 07:17:17'),
(15, 'CAT015', 'Clothings', '6528218945man-with-fireworks-769525.jpg', 0, 1, 'Active', '', '2020-04-10 01:36:33'),
(16, 'CAT016', 'Footwear', '7638818945man-with-fireworks-769525.jpg', 0, 1, 'Active', '', '2020-04-10 01:36:33'),
(17, 'CAT017', 'Shoes', '4151018945man-with-fireworks-769525.jpg', 0, 1, 'Active', 'Shoes', '2020-04-10 01:36:33'),
(18, 'CAT018', 'Jewellery', '1548318945man-with-fireworks-769525.jpg', 0, 1, 'Active', '', '2020-04-10 01:36:33'),
(19, 'CAT019', 'Toys', '5303511503pexels-photo-2608517.jpeg', 0, 1, 'Active', '', '2020-04-10 01:36:33'),
(20, 'CAT020', 'Baby care', '6317210084pexels-photo-414807.jpeg', 0, 1, 'Active', '', '2020-04-10 01:36:33'),
(21, 'CAT021', 'Fruits', '10484veggie-reu_l.jpg', 0, 1, 'Active', '', '2020-04-10 15:13:12'),
(22, 'CAT022', 'Mens', '88694springfield_illinois.jpg', 0, 1, 'Active', '', '2020-04-11 15:27:16');

-- --------------------------------------------------------

--
-- Table structure for table `vv_job_sub_categories`
--

CREATE TABLE `vv_job_sub_categories` (
  `sub_category_id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `sub_category_code` varchar(20) DEFAULT NULL,
  `sub_category_name` text,
  `sub_category_image` text,
  `sub_category_status` varchar(20) DEFAULT NULL,
  `sub_category_slug` text,
  `sub_category_cdt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vv_job_sub_categories`
--

INSERT INTO `vv_job_sub_categories` (`sub_category_id`, `category_id`, `sub_category_code`, `sub_category_name`, `sub_category_image`, `sub_category_status`, `sub_category_slug`, `sub_category_cdt`) VALUES
(8, 6, 'SUB_CAT008', 'Mobiles', '', 'Active', '', '2020-04-08 10:19:36'),
(9, 6, 'SUB_CAT009', 'Smart TV', '', 'Active', '', '2020-04-08 10:19:36'),
(10, 6, 'SUB_CAT010', 'Laptop', '', 'Active', '', '2020-04-08 10:19:36'),
(11, 6, 'SUB_CAT011', 'Speakers', '', 'Active', '', '2020-04-08 10:19:36'),
(12, 6, 'SUB_CAT012', 'Camera', '', 'Active', '', '2020-04-08 10:19:36'),
(13, 6, 'SUB_CAT013', 'Tablets', '', 'Active', '', '2020-04-08 10:19:36'),
(14, 6, 'SUB_CAT014', 'Smart Tech', '', 'Active', '', '2020-04-08 10:19:36'),
(15, 17, 'SUB_CAT015', 'Adidas', '', 'Active', '', '2020-04-10 01:37:25'),
(16, 17, 'SUB_CAT016', 'Nike', '', 'Active', '', '2020-04-10 01:37:25'),
(17, 17, 'SUB_CAT017', 'Puma', '', 'Active', '', '2020-04-10 01:37:25'),
(18, 19, 'SUB_CAT018', 'Educations toys', '', 'Active', '', '2020-04-10 01:38:17'),
(19, 19, 'SUB_CAT019', 'Brain games', '', 'Active', '', '2020-04-10 01:38:17'),
(20, 19, 'SUB_CAT020', 'Drone toys', '', 'Active', '', '2020-04-10 01:38:17'),
(21, 19, 'SUB_CAT021', 'Playstations games', '', 'Active', '', '2020-04-10 01:38:17'),
(22, 19, 'SUB_CAT022', 'PC games', '', 'Active', '', '2020-04-10 01:38:17'),
(23, 15, 'SUB_CAT023', 'T-shirts', '', 'Active', '', '2020-04-10 01:38:49'),
(24, 15, 'SUB_CAT024', 'Shirts', '', 'Active', '', '2020-04-10 01:38:49'),
(25, 15, 'SUB_CAT025', 'Jeans', '', 'Active', '', '2020-04-10 01:38:49'),
(26, 7, 'SUB_CAT026', 'Books', '', 'Active', '', '2020-04-10 15:04:44'),
(27, 7, 'SUB_CAT027', 'Digital books', '', 'Active', '', '2020-04-10 15:04:44'),
(28, 7, 'SUB_CAT028', 'Digital products', '', 'Active', '', '2020-04-10 15:04:44'),
(29, 21, 'SUB_CAT029', 'Fruits', '', 'Active', '', '2020-04-10 15:13:51'),
(30, 21, 'SUB_CAT030', 'Vegitables', '', 'Active', '', '2020-04-10 15:13:51'),
(31, 21, 'SUB_CAT031', 'Fruits and vegitables', '', 'Active', '', '2020-04-10 15:13:51'),
(32, 6, 'SUB_CAT032', 'Camera holder', '', 'Active', '', '2020-04-11 15:19:18'),
(33, 6, 'SUB_CAT033', 'Camera pouch', '', 'Active', '', '2020-04-11 15:19:18'),
(34, 6, 'SUB_CAT034', 'Camera light', '', 'Active', '', '2020-04-11 15:19:18'),
(35, 6, 'SUB_CAT035', 'Camera lense', '', 'Active', '', '2020-04-11 15:19:18'),
(36, 22, 'SUB_CAT036', 'Smart watches', '', 'Active', '', '2020-04-11 15:28:13'),
(37, 22, 'SUB_CAT037', 'Tshirts', '', 'Active', '', '2020-04-11 15:28:13'),
(38, 23, 'SUB_CAT038', 'Food', '', 'Active', '', '2020-04-27 21:57:58'),
(39, 23, 'SUB_CAT039', 'Protein', '', 'Active', '', '2020-04-27 21:57:58'),
(40, 23, 'SUB_CAT040', 'Health products', '', 'Active', '', '2020-04-27 21:57:58'),
(41, 23, 'SUB_CAT041', 'Diet food', '', 'Active', '', '2020-04-27 21:57:58');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `vv_custom_css`
--
ALTER TABLE `vv_custom_css`
  ADD PRIMARY KEY (`custom_css_id`);

--
-- Indexes for table `vv_experts`
--
ALTER TABLE `vv_experts`
  ADD PRIMARY KEY (`expert_id`);

--
-- Indexes for table `vv_expert_areas`
--
ALTER TABLE `vv_expert_areas`
  ADD PRIMARY KEY (`city_id`);

--
-- Indexes for table `vv_expert_categories`
--
ALTER TABLE `vv_expert_categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `vv_expert_cities`
--
ALTER TABLE `vv_expert_cities`
  ADD PRIMARY KEY (`country_id`);

--
-- Indexes for table `vv_expert_enquiries`
--
ALTER TABLE `vv_expert_enquiries`
  ADD PRIMARY KEY (`enquiry_id`);

--
-- Indexes for table `vv_expert_payments`
--
ALTER TABLE `vv_expert_payments`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `vv_expert_reviews`
--
ALTER TABLE `vv_expert_reviews`
  ADD PRIMARY KEY (`review_id`);

--
-- Indexes for table `vv_expert_sub_categories`
--
ALTER TABLE `vv_expert_sub_categories`
  ADD PRIMARY KEY (`sub_category_id`);

--
-- Indexes for table `vv_jobs`
--
ALTER TABLE `vv_jobs`
  ADD PRIMARY KEY (`job_id`);

--
-- Indexes for table `vv_job_applied`
--
ALTER TABLE `vv_job_applied`
  ADD PRIMARY KEY (`job_applied_id`);

--
-- Indexes for table `vv_job_categories`
--
ALTER TABLE `vv_job_categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `vv_job_cities`
--
ALTER TABLE `vv_job_cities`
  ADD PRIMARY KEY (`city_id`);

--
-- Indexes for table `vv_job_popular`
--
ALTER TABLE `vv_job_popular`
  ADD PRIMARY KEY (`job_popular_id`);

--
-- Indexes for table `vv_job_profile`
--
ALTER TABLE `vv_job_profile`
  ADD PRIMARY KEY (`job_profile_id`);

--
-- Indexes for table `vv_job_skill`
--
ALTER TABLE `vv_job_skill`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `vv_job_sub_categories`
--
ALTER TABLE `vv_job_sub_categories`
  ADD PRIMARY KEY (`sub_category_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `vv_custom_css`
--
ALTER TABLE `vv_custom_css`
  MODIFY `custom_css_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `vv_experts`
--
ALTER TABLE `vv_experts`
  MODIFY `expert_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `vv_expert_areas`
--
ALTER TABLE `vv_expert_areas`
  MODIFY `city_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `vv_expert_categories`
--
ALTER TABLE `vv_expert_categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `vv_expert_cities`
--
ALTER TABLE `vv_expert_cities`
  MODIFY `country_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `vv_expert_enquiries`
--
ALTER TABLE `vv_expert_enquiries`
  MODIFY `enquiry_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `vv_expert_payments`
--
ALTER TABLE `vv_expert_payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `vv_expert_reviews`
--
ALTER TABLE `vv_expert_reviews`
  MODIFY `review_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `vv_expert_sub_categories`
--
ALTER TABLE `vv_expert_sub_categories`
  MODIFY `sub_category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;
--
-- AUTO_INCREMENT for table `vv_jobs`
--
ALTER TABLE `vv_jobs`
  MODIFY `job_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `vv_job_applied`
--
ALTER TABLE `vv_job_applied`
  MODIFY `job_applied_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `vv_job_categories`
--
ALTER TABLE `vv_job_categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `vv_job_cities`
--
ALTER TABLE `vv_job_cities`
  MODIFY `city_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `vv_job_popular`
--
ALTER TABLE `vv_job_popular`
  MODIFY `job_popular_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `vv_job_profile`
--
ALTER TABLE `vv_job_profile`
  MODIFY `job_profile_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `vv_job_skill`
--
ALTER TABLE `vv_job_skill`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
  
  -- *******************  Adding new columns for existing tables starts *******************************
--
-- ADD New column for table `vv_admin`
--
ALTER TABLE `vv_admin` ADD admin_recovery_email VARCHAR(100) AFTER admin_password;

--
-- ADD New column for table `vv_admin`
--
ALTER TABLE `vv_admin` ADD activation_date DATETIME NULL AFTER admin_mail_template_options;
UPDATE `vv_admin` SET activation_date = '0000-00-00 00:00:00';
ALTER TABLE `vv_admin` MODIFY activation_date DATETIME NOT NULL;

--
-- ADD New column for table `vv_admin`
--
ALTER TABLE `vv_admin` ADD expiry_date DATETIME NULL AFTER activation_date;
UPDATE `vv_admin` SET expiry_date = '0000-00-00 00:00:00';
ALTER TABLE `vv_admin` MODIFY expiry_date DATETIME NOT NULL;

--
-- ADD New column for table `vv_admin`
--
ALTER TABLE `vv_admin` ADD activation_code TEXT NOT NULL AFTER expiry_date;

--
-- ADD New column for table `vv_admin`
--
ALTER TABLE `vv_admin` ADD activation_status INT NULL DEFAULT 0 AFTER activation_code;

--
-- ADD New column for table `vv_footer`
--
ALTER TABLE `vv_footer` ADD header_logo_width VARCHAR(50) AFTER mobile_view_logo;

--
-- ADD New column for table `vv_footer`
--
ALTER TABLE `vv_footer` ADD header_logo_height VARCHAR(50) AFTER header_logo_width;

--
-- ADD New column for table `vv_footer`
--
ALTER TABLE `vv_footer` ADD admin_mobile_app_feature INT NULL DEFAULT 1 AFTER admin_share_pinterest;

--
-- ADD New column for table `vv_footer`
--
ALTER TABLE `vv_footer` ADD admin_footer_mobile_app_feature INT NULL DEFAULT 1 AFTER admin_mobile_app_feature;

--
-- ADD New column for table `vv_footer`
--
ALTER TABLE `vv_footer` ADD admin_country_list_feature INT NULL DEFAULT 1 AFTER admin_footer_mobile_app_feature;

--
-- ADD New column for table `vv_footer`
--
ALTER TABLE `vv_footer` ADD admin_get_in_touch_feature INT NULL DEFAULT 1 AFTER admin_country_list_feature;

--
-- ADD New column for table `vv_footer`
--
ALTER TABLE `vv_footer` ADD admin_service_expert_email TEXT NOT NULL AFTER footer_country_url_7;

--
-- ADD New column for table `vv_footer`
--
ALTER TABLE `vv_footer` ADD admin_service_expert_mobile TEXT NOT NULL AFTER admin_service_expert_email;

--
-- ADD New column for table `vv_footer`
--
ALTER TABLE `vv_footer` ADD admin_service_expert_whatsapp TEXT NOT NULL AFTER admin_service_expert_mobile;

--
-- ADD New column for table `vv_page_views`
--
ALTER TABLE `vv_page_views` ADD job_id INT NULL AFTER product_id;

--
-- ADD New column for table `vv_page_views`
--
ALTER TABLE `vv_page_views` ADD job_profile_id INT NULL AFTER job_id;

--
-- ADD New column for table `vv_page_views`
--
ALTER TABLE `vv_page_views` ADD expert_id INT NULL AFTER job_profile_id;

--
-- ADD New column for table `vv_plan_type`
--
ALTER TABLE `vv_plan_type` ADD plan_type_job_count INT NULL AFTER plan_type_blog_count;

--
-- ADD New column for table `vv_users`
--
ALTER TABLE `vv_users` ADD cover_image TEXT NOT NULL AFTER profile_image;

--
-- ADD New column for table `vv_users`
--
ALTER TABLE `vv_users` ADD setting_listing_show INT NULL DEFAULT 1 AFTER setting_user_status;

--
-- ADD New column for table `vv_users`
--
ALTER TABLE `vv_users` ADD setting_job_show INT NULL DEFAULT 1 AFTER setting_listing_show;

--
-- ADD New column for table `vv_users`
--
ALTER TABLE `vv_users` ADD setting_expert_show INT NULL DEFAULT 1 AFTER setting_job_show;

--
-- ADD New column for table `vv_users`
--
ALTER TABLE `vv_users` ADD setting_product_show INT NULL DEFAULT 1 AFTER setting_expert_show;

--
-- ADD New column for table `vv_users`
--
ALTER TABLE `vv_users` ADD setting_blog_show INT NULL DEFAULT 1 AFTER setting_product_show;

--
-- ADD New column for table `vv_users`
--
ALTER TABLE `vv_users` ADD setting_event_show INT NULL DEFAULT 1 AFTER setting_blog_show;

--
-- ADD New column for table `vv_users`
--
ALTER TABLE `vv_users` ADD setting_coupon_show INT NULL DEFAULT 1 AFTER setting_event_show;

--
-- ADD New column for table `vv_users`
--
ALTER TABLE `vv_users` ADD user_clear_notification_cdt DATETIME NULL AFTER verification_status;
UPDATE `vv_users` SET user_clear_notification_cdt = '0000-00-00 00:00:00';
ALTER TABLE `vv_users` MODIFY user_clear_notification_cdt DATETIME NOT NULL;

-- *******************  Adding new columns for existing tables ends *******************************
  
--
-- AUTO_INCREMENT for table `vv_job_sub_categories`
--
ALTER TABLE `vv_job_sub_categories`
  MODIFY `sub_category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;COMMIT;
 

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
