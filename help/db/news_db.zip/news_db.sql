-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 02, 2022 at 09:58 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bizbook_plus_directory`
--

-- --------------------------------------------------------

--
-- Table structure for table `vv_news`
--

CREATE TABLE `vv_news` (
  `news_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `news_title` varchar(100) NOT NULL,
  `news_description` text NOT NULL,
  `news_image` text NOT NULL,
  `seo_title` text NOT NULL,
  `seo_description` text NOT NULL,
  `seo_keywords` text NOT NULL,
  `news_status` varchar(20) NOT NULL,
  `news_slug` varchar(100) NOT NULL,
  `news_cdt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vv_news`
--

INSERT INTO `vv_news` (`news_id`, `category_id`, `news_title`, `news_description`, `news_image`, `seo_title`, `seo_description`, `seo_keywords`, `news_status`, `news_slug`, `news_cdt`) VALUES
(2, 18, 'U.S. Futures Rise as Traders Mull Virus, China Vow: Markets Wrap', 'Asian stocks were mixed and U.S. equity futures were steady Monday amid a mood of caution as traders evaluated spiking coronavirus cases and a weekend pledge of greater economic support from Chinaâ€™s central bank.\r\n\r\nShares fell in Japan and fluctuated in China, where the nationâ€™s monetary authority Saturday pledged greater support for the real economy and reiterated a goal of â€œhealthyâ€ growth in the property sector.\r\n\r\nAsian stocks were mixed and U.S. equity futures were steady Monday amid a mood of caution as traders evaluated spiking coronavirus cases and a weekend pledge of greater economic support from Chinaâ€™s central bank.\r\n\r\nShares fell in Japan and fluctuated in China, where the nationâ€™s monetary authority Saturday pledged greater support for the real economy and reiterated a goal of â€œhealthyâ€ growth in the property sector.\r\n\r\nAsian stocks were mixed and U.S. equity futures were steady Monday amid a mood of caution as traders evaluated spiking coronavirus cases and a weekend pledge of greater economic support from Chinaâ€™s central bank.\r\n\r\nShares fell in Japan and fluctuated in China, where the nationâ€™s monetary authority Saturday pledged greater support for the real economy and reiterated a goal of â€œhealthyâ€ growth in the property sector.\r\n\r\n', '1450bean3.jpg', 'test viki title007', 'test viki description007', 'test viki keywords007', 'Active', 'U S  Futures Rise as Traders Mull Virus  China Vow  Markets Wrap', '2021-12-27 12:45:53');

-- --------------------------------------------------------

--
-- Table structure for table `vv_news_categories`
--

CREATE TABLE `vv_news_categories` (
  `category_id` int(11) NOT NULL,
  `category_code` varchar(20) DEFAULT NULL,
  `category_name` text NOT NULL,
  `category_image` text NOT NULL,
  `category_seo_title` text NOT NULL,
  `category_seo_description` text NOT NULL,
  `category_seo_keywords` text NOT NULL,
  `category_filter` int(11) NOT NULL DEFAULT '0',
  `category_filter_pos_id` int(11) NOT NULL,
  `category_status` varchar(20) NOT NULL,
  `category_slug` text NOT NULL,
  `category_cdt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vv_news_categories`
--

INSERT INTO `vv_news_categories` (`category_id`, `category_code`, `category_name`, `category_image`, `category_seo_title`, `category_seo_description`, `category_seo_keywords`, `category_filter`, `category_filter_pos_id`, `category_status`, `category_slug`, `category_cdt`) VALUES
(17, 'CAT017', 'Sports', '', '', '', '', 0, 5, 'Active', 'Sports', '2020-04-10 01:36:33'),
(18, 'CAT018', 'Others', '', '', '', '', 0, 6, 'Active', 'Others', '2020-04-10 01:36:33'),
(19, 'CAT019', 'World', '', '', '', '', 0, 3, 'Active', 'World', '2020-04-10 01:36:33'),
(20, 'CAT020', 'Health', '', '', '', '', 0, 4, 'Active', 'Health', '2020-04-10 01:36:33'),
(21, 'CAT021', 'Politics', '', '', '', '', 0, 2, 'Active', 'Politics', '2020-04-10 15:13:12'),
(22, 'CAT022', 'Entertainment', '', '', '', '', 0, 0, 'Active', 'Entertainment', '2020-04-11 15:27:16'),
(23, 'CAT023', 'Tech', '', 'news category seo title', 'news category test description', 'news category seo keywords', 0, 1, 'Active', 'Tech', '2020-04-27 21:56:45');

-- --------------------------------------------------------

--
-- Table structure for table `vv_news_slider`
--

CREATE TABLE `vv_news_slider` (
  `news_slider_id` int(11) NOT NULL,
  `news_id` int(11) NOT NULL,
  `news_slider_pos_id` int(11) NOT NULL,
  `news_slider_cdt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vv_news_slider`
--

INSERT INTO `vv_news_slider` (`news_slider_id`, `news_id`, `news_slider_pos_id`, `news_slider_cdt`) VALUES
(1, 2, 1, '2022-01-03 05:15:15'),
(2, 14, 2, '2022-01-03 10:13:13'),
(3, 10, 3, '2022-01-03 14:25:19'),
(4, 1, 4, '2022-01-03 05:14:14'),
(5, 11, 5, '2022-01-03 05:15:15');

-- --------------------------------------------------------

--
-- Table structure for table `vv_news_social_media`
--

CREATE TABLE `vv_news_social_media` (
  `social_media_id` int(11) NOT NULL,
  `social_media_name` varchar(20) NOT NULL,
  `social_media_link` text NOT NULL,
  `social_media_count` varchar(20) NOT NULL,
  `social_media_status` int(11) NOT NULL,
  `social_media_cdt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vv_news_social_media`
--

INSERT INTO `vv_news_social_media` (`social_media_id`, `social_media_name`, `social_media_link`, `social_media_count`, `social_media_status`, `social_media_cdt`) VALUES
(1, 'Facebook', 'https://m.facebook.com/rn53themes/?locale2=fr_FR', '5k', 1, '2022-01-23 08:22:22'),
(2, 'Twitter', 'https://twitter.com/rn53_themes', '10K', 1, '2022-01-23 08:20:20'),
(3, 'Linkedin', 'https://twitter.com/rn53_themes', '1k', 1, '2022-01-23 08:22:22'),
(4, 'Youtube', 'https://www.youtube.com/channel/UC3wN3O2GXTt7ZZniIoMZumg', '100K', 1, '2022-01-23 08:20:20');

-- --------------------------------------------------------

--
-- Table structure for table `vv_news_subscribers`
--

CREATE TABLE `vv_news_subscribers` (
  `news_subscribers_id` int(11) NOT NULL,
  `subscriber_email_id` text,
  `news_subscribers_cdt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vv_news_trending`
--

CREATE TABLE `vv_news_trending` (
  `trending_news_id` int(11) NOT NULL,
  `news_id` int(11) NOT NULL,
  `trending_news_pos_id` int(11) NOT NULL,
  `trending_news_cdt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vv_news_trending`
--

INSERT INTO `vv_news_trending` (`trending_news_id`, `news_id`, `trending_news_pos_id`, `trending_news_cdt`) VALUES
(1, 2, 1, '2022-01-03 08:18:17'),
(2, 14, 2, '2022-01-03 10:13:13'),
(3, 10, 3, '2022-01-03 14:25:19'),
(4, 1, 4, '2022-01-03 05:14:14'),
(5, 11, 5, '2022-01-03 05:15:15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `vv_news`
--
ALTER TABLE `vv_news`
  ADD PRIMARY KEY (`news_id`);

--
-- Indexes for table `vv_news_categories`
--
ALTER TABLE `vv_news_categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `vv_news_slider`
--
ALTER TABLE `vv_news_slider`
  ADD PRIMARY KEY (`news_slider_id`);

--
-- Indexes for table `vv_news_social_media`
--
ALTER TABLE `vv_news_social_media`
  ADD PRIMARY KEY (`social_media_id`);

--
-- Indexes for table `vv_news_subscribers`
--
ALTER TABLE `vv_news_subscribers`
  ADD PRIMARY KEY (`news_subscribers_id`);

--
-- Indexes for table `vv_news_trending`
--
ALTER TABLE `vv_news_trending`
  ADD PRIMARY KEY (`trending_news_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `vv_news`
--
ALTER TABLE `vv_news`
  MODIFY `news_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `vv_news_categories`
--
ALTER TABLE `vv_news_categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `vv_news_slider`
--
ALTER TABLE `vv_news_slider`
  MODIFY `news_slider_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `vv_news_social_media`
--
ALTER TABLE `vv_news_social_media`
  MODIFY `social_media_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `vv_news_subscribers`
--
ALTER TABLE `vv_news_subscribers`
  MODIFY `news_subscribers_id` int(11) NOT NULL AUTO_INCREMENT;
  
-- *******************  Adding new columns for existing tables starts *******************************
  
--
-- ADD New column for table `vv_page_views`
--
ALTER TABLE `vv_page_views` ADD news_id INT NULL AFTER expert_id;

--
-- ADD New column for table `vv_admin`
--
ALTER TABLE `vv_admin` ADD admin_jobs_options INT NULL DEFAULT 1 AFTER admin_product_options;

--
-- ADD New column for table `vv_admin`
--
ALTER TABLE `vv_admin` ADD admin_service_expert_options INT NULL DEFAULT 1 AFTER admin_jobs_options;

--
-- ADD New column for table `vv_admin`
--
ALTER TABLE `vv_admin` ADD admin_news_options INT NULL DEFAULT 1 AFTER admin_service_expert_options;

--
-- ADD New column for table `vv_admin`
--
ALTER TABLE `vv_admin` ADD admin_seo_setting_options INT NULL DEFAULT 1 AFTER admin_news_options;

--
-- ADD New column for table `vv_admin`
--
ALTER TABLE `vv_admin` ADD admin_appearance_options INT NULL DEFAULT 1 AFTER admin_seo_setting_options;
  
-- *******************  Adding new columns for existing tables ends *******************************  
  
--
-- AUTO_INCREMENT for table `vv_news_trending`
--
ALTER TABLE `vv_news_trending`
  MODIFY `trending_news_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
